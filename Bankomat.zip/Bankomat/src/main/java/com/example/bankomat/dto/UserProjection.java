package com.example.bankomat.dto;

public interface UserProjection {
    String getEmail();
    String getUsername();
    Long getId();
}
