package com.example.bankomat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankomatApplicationTests {

    @Test
    void contextLoads() {
    }

}
