package com.company.api_auth.enums;

public enum ProfileStatus {
    ACTIVE,
    BLOCK,
    CREATED
}
