package com.company.api_auth.controller;

import com.company.api_auth.dto.AuthorizationDTO;
import com.company.api_auth.dto.ProfileDTO;
import com.company.api_auth.dto.RegistrationDTO;
import com.company.api_auth.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/auth")
public class AuthController {
    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<ProfileDTO> login(@RequestBody AuthorizationDTO dto) {
        ProfileDTO response = authService.authorization(dto);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/registration")
    public ResponseEntity registration(@RequestBody RegistrationDTO dto) {
        authService.registration(dto);
        return ResponseEntity.ok("Successfully!!!");
    }

    @GetMapping("/verification/{jwt}")
    public ResponseEntity verify(@PathVariable String jwt) {
        authService.verify(jwt);
        System.out.println(jwt);
        return ResponseEntity.ok("Success");
    }


}
