package com.company.api_auth.dto;


import com.company.api_auth.enums.ProfileOrderStatus;
import com.company.api_auth.enums.ProfileStatus;
import lombok.Data;

import javax.management.relation.Role;
import java.time.LocalDate;

@Data
public class ProfileFilterDTO {
    private Integer id;
    private String name;
    private String surname;
    private String email;
    private Role role;
    private ProfileStatus status;
    private LocalDate fromDate;
    private LocalDate toDate;
    private ProfileOrderStatus orderBy = ProfileOrderStatus.ID_ASC;
}
