package com.company.api_auth.enums;

public enum Role {
    USER_ROLE,
    MODERATOR_ROLE,
    PUBLISHER_ROLE,
    ADMIN_ROLE
}
