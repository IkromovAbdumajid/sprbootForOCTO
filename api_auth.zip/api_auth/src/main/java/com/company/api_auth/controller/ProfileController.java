package com.company.api_auth.controller;

import com.company.api_auth.dto.ProfileDTO;
import com.company.api_auth.dto.ProfileFilterDTO;
import com.company.api_auth.dto.ProfileJwtDTO;
import com.company.api_auth.enums.Role;
import com.company.api_auth.service.ProfileService;
import com.company.api_auth.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/profile")

public class ProfileController {
    @Autowired
    private ProfileService profileService;


    public ResponseEntity create(@RequestBody ProfileDTO dto,
                                 HttpServletRequest request) {

        ProfileJwtDTO jwtDTO = JwtUtil.getProfile(request, Role.ADMIN_ROLE);
        ProfileDTO response = profileService.create(dto);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity getAll(HttpServletRequest request) {
        ProfileJwtDTO jwtDTO = JwtUtil.getProfile(request, Role.ADMIN_ROLE);
        return ResponseEntity.ok(profileService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity getById(@PathVariable Integer id, HttpServletRequest request) {
        ProfileJwtDTO jwtDTO = JwtUtil.getProfile(request, Role.ADMIN_ROLE);
        return ResponseEntity.ok(profileService.getById(id));
    }

    @PutMapping
    public ResponseEntity update(@RequestBody ProfileDTO dto,
                                 HttpServletRequest request) {
        ProfileJwtDTO jwtDTO = JwtUtil.getProfile(request);
        return ResponseEntity.ok(profileService.update(dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity deleteById(@PathVariable("id") Integer id,
                                     HttpServletRequest request) {
        ProfileJwtDTO jwtDTO = JwtUtil.getProfile(request, Role.ADMIN_ROLE);
        return ResponseEntity.ok(profileService.deleteById(id));
    }

    @PostMapping("/filter")
    public ResponseEntity filter(@RequestParam("page") int page,
                                 @RequestParam("size") int size,
                                 @RequestBody ProfileFilterDTO dto) {
        return ResponseEntity.ok(profileService.filterSpec(page, size, dto));
    }

}