package com.company.api_auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiAuthApplicationTests {

    @Test
    void contextLoads() {
    }

}
