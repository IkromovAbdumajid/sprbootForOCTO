package com.example.gmrestapi.dto;

import com.example.gmrestapi.entity.Car;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Autoshopdtoclient {
    private String corpName;
    private String director;
    private String home;
    private String street;
    private String city;
}
