package com.example.gmrestapi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
//web un xavfsizlikni yoq
@EnableWebSecurity
//metodlar un xavfsizlik yoq
@EnableGlobalMethodSecurity(securedEnabled = true, jsr250Enabled = true, prePostEnabled = true)
public class Xavfsizlik extends WebSecurityConfigurerAdapter {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }


    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        //tizimda bazasiz bir nechta userdan foydalanish imkonini berib turibti
        auth.inMemoryAuthentication()
                .withUser("admin").password(passwordEncoder().encode("admin")).roles("ADMIN")
                .and()
                .withUser("user").password(passwordEncoder().encode("user")).roles("USER")
                .and()
                .withUser("moderator").password(passwordEncoder().encode("moderator")).roles("MODERATOR");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                //non browser client postman robot http request un ochiq
                .csrf().disable()
                //post put delete frontdan keladigan http zaproslar uchun ochilsin
                .cors().disable()
                .authorizeRequests()
                .antMatchers(HttpMethod.POST, "/api/gm/**").hasRole("ADMIN")
                .antMatchers(HttpMethod.PUT, "/api/gm/**").hasAnyRole("ADMIN", "MODERATOR")
                .antMatchers(HttpMethod.GET, "/api/gm/**").hasAnyRole("ADMIN", "MODERATOR")
                .anyRequest()
                .authenticated()
                .and()
                //login va parol bilan kelish kerak
                .httpBasic(); //
    }
}
