package com.example.gmrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GmRestApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
