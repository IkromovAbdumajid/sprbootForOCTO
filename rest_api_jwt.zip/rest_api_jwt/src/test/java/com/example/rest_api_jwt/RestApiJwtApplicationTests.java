package com.example.rest_api_jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiJwtApplicationTests {

    @Test
    void contextLoads() {
    }

}
