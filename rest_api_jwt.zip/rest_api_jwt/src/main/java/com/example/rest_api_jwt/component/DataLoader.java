package com.example.rest_api_jwt.component;

import com.example.rest_api_jwt.Repository.UserRepository;
import com.example.rest_api_jwt.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestController;
@RequiredArgsConstructor

@Component
public class DataLoader  implements CommandLineRunner {
 final UserRepository userRepository;

    @Override
    public void run(String... args) throws Exception {
userRepository.save(new User("143567890","user"));
        userRepository.save(new User("123","admin"));
        userRepository.save(new User("123","materator"));
    }
}
