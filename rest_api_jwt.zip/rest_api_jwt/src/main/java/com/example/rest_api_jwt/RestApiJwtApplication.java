package com.example.rest_api_jwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiJwtApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestApiJwtApplication.class, args);
    }

}
