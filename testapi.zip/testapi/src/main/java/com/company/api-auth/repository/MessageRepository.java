package com.company.api_auth.repository;

import com.company.api_auth.entity.MessageEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface MessageRepository extends JpaRepository<MessageEntity, Integer> {

    @Query(value = "SELECT * FROM message m WHERE m.date::DATE = now()", nativeQuery = true)
    List<MessageEntity> findTodays();

    Page<MessageEntity> findByUsedIsFalse(Pageable pageable);

    Optional<MessageEntity> findTopByOrderByCreatedDateDesc();

}
