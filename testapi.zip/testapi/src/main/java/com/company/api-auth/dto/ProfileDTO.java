package com.company.api_auth.dto;


import com.company.api_auth.enums.Role;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProfileDTO {
    private Integer id;
    private String name;

    private String surname;

    private String login;

    private String password;

    private String email;

    private Role role;

    private LocalDateTime createdDate;

    private String jwt; // token
}
