package com.company.api_auth.exception;

public class UnauthorizaedException extends RuntimeException {
    public UnauthorizaedException(String message) {
        super(message);
    }
}
