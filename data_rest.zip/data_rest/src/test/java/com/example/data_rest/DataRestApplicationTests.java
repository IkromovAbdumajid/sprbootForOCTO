package com.example.data_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
