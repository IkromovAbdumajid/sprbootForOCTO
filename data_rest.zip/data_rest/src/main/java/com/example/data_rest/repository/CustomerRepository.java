package com.example.data_rest.repository;

import com.example.data_rest.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path = "customer", collectionResourceRel = "CUSTOMER")
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
}
