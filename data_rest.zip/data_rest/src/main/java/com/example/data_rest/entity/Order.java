package com.example.data_rest.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.util.Date;
import java.util.List;

@Entity(name = "orders")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer id;


  //  @CreationTimestamp
    //@CreatedDate
    @Column(nullable = false)
   // private Date date= new Date(LocalDate.now().get(ChronoField.EPOCH_DAY));
    private  LocalDate data=LocalDate.now();

    @ManyToOne
    public Customer customer;

    @OneToMany (mappedBy ="orders" )
    private List<Detail> detailList;
}
