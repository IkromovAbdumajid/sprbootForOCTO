package com.example.data_rest.repository;

import com.example.data_rest.entity.Order;
import lombok.Value;
import org.springframework.data.rest.core.config.Projection;

@Projection(types = {Order.class},name = "customOrder")
public interface CustomOrder {

//    @Value(staticConstructor = "#{target.customer}")
}
