package com.example.data_rest.repository;

import com.example.data_rest.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path = "product",collectionResourceRel = "product")
public interface ProductRepository extends JpaRepository<Product,Integer> {
}
