package com.example.data_rest.repository;

import com.example.data_rest.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@RepositoryRestResource(path = "category",collectionResourceRel = "categoty")
public interface CategoryRepository extends JpaRepository<Category,Integer> {
    //add search in url
//    @RestResource(path = "/name")
//    List<Category> findAllByNameContainingIgnoreCase(@Param("") String name);
}
