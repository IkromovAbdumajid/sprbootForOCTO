package com.example.data_rest.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Invoice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer id;


    @ManyToOne
    public Order ord_id;




    @Column(precision = 8,scale = 2,nullable = false)
    private BigDecimal amount;

    @Column(nullable = false)
    // private Date date= new Date(LocalDate.now().get(ChronoField.EPOCH_DAY));
    private Date issued;


    @Column(nullable = false)
    private Date due;

}
